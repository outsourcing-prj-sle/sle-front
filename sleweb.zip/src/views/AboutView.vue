<template>
  <div class="flex flex-col bg-white">
    <header
      class="flex gap-5 justify-between py-1.5 pr-9 pl-20 w-full border border-solid border-neutral-200 max-md:flex-wrap max-md:px-5 max-md:max-w-full"
    >
      <div class="flex gap-2 my-auto">
        <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/6fcc5f03c64d461e0edad3db0c2877730548fd50140b3349830cc357782684f3?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Socio-Emotional Learning Logo" class="shrink-0 max-w-full aspect-[3.45] w-[129px]" /> -->
        <!-- <div class="flex gap-px self-start mt-5">
          <div class="grow text-sm text-neutral-500">과 함께하는</div>
          <div class="flex-auto text-base font-bold text-violet-950">SEL 사회정서학습</div>
        </div> -->
      </div>
      <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/28a92f9b038a33e72ad112cda7b19386aeb5c3a38865905e586688b9a0466295?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Another learning related image" class="shrink-0 max-w-full aspect-[2.22] w-[117px]" /> -->
    </header>
    <div
      class="justify-center items-start py-5 pr-16 pl-24 w-full text-base font-medium text-black bg-white max-md:pr-5 max-md:pl-8 max-md:max-w-full"
    >
      나의 SEL 알기
    </div>
    <section
      class="flex overflow-hidden relative flex-col items-center px-16 pt-12 w-full min-h-[341px] max-md:px-5 max-md:max-w-full"
    >
      <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/44bfc0d261b637f96d1b3558a47aa8b6cb710eb930d38c33def5e5deb0ee6a03?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Background image related to learning" class="object-cover absolute inset-0 size-full" /> -->
      <div class="relative w-full max-w-[1089px] max-md:max-w-full">
        <div class="flex gap-5 max-md:flex-col max-md:gap-0">
          <div class="flex flex-col w-[21%] max-md:ml-0 max-md:w-full">
            <div class="flex relative grow gap-0 max-md:mt-9">
              <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/ed86a9aedb3a03c3db69359401d01cf0fb9c64d3191e8cc43ad55528075abfef?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Additional decorative image" class="shrink-0 self-start mt-5 aspect-[0.98] w-[43px]" /> -->
              <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/4d1335dfcf5e84495e297ae24d041c9982d39a63d3a1ce7115fdae14192b154d?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Another decorative image" class="shrink-0 max-w-full aspect-[0.59] w-[174px]" /> -->
            </div>
          </div>
          <article class="flex flex-col ml-5 w-[79%] max-md:ml-0 max-md:w-full">
            <div class="relative grow mt-8 max-md:mt-10 max-md:max-w-full">
              <div class="flex gap-5 max-md:flex-col max-md:gap-0">
                <div class="flex flex-col w-[78%] max-md:ml-0 max-md:w-full">
                  <div
                    class="flex relative flex-col max-md:mt-10 max-md:max-w-full"
                  >
                    <div
                      class="flex gap-2 items-end self-center max-md:flex-wrap"
                    >
                      <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/03e5a21a2db2abdbc9a43c05f5315a1b6dd3821e137f3655266c832f3eb34d44?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Another SEL learning image" class="self-stretch aspect-[3.45] w-[235px]" /> -->
                      <div
                        class="mt-12 text-lg font-medium text-black max-md:mt-10"
                      >
                        과 함께하는
                      </div>
                      <div
                        class="flex-auto mt-11 text-2xl font-bold text-violet-950 max-md:mt-10"
                      >
                        SEL 사회정서학습
                      </div>
                    </div>
                    <div
                      class="mt-12 text-lg font-medium leading-6 text-center text-red-600 max-md:mt-10 max-md:max-w-full"
                    >
                      ‘ID’란 자신의
                      <span class="font-bold text-red-600">고유한 정체성</span
                      >(Identity)으로
                      <span class="font-bold text-red-600"
                        >‘SEL 사회정서학습’</span
                      >
                      학습분석 결과를 통해<br />
                      <span class="text-gray-500">스스로 관찰하고 원하는</span>
                      목표<span class="text-gray-500">와 꿈을 발견</span
                      >하여,<br />
                      이를 실현하기 위해 반응하는
                      <span class="font-bold text-red-600"
                        >아동으로 성장하는 것을 의미</span
                      >합니다.
                    </div>
                  </div>
                </div>
                <div
                  class="flex flex-col ml-5 w-[22%] max-md:ml-0 max-md:w-full"
                >
                  <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/911d47c357c79dcfd62f5b1c1bb5d4c0bfae0a5cdc09fb9f1b491894c5b43d04?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Decorative image on the right" class="grow shrink-0 mt-2 max-w-full aspect-[0.64] w-[163px] max-md:mt-10" /> -->
                </div>
              </div>
            </div>
          </article>
        </div>
      </div>
    </section>
    <section
      class="flex flex-col px-14 mt-24 w-full max-md:px-5 max-md:mt-10 max-md:max-w-full"
    >
      <div
        class="flex gap-5 justify-between items-start w-full max-md:flex-wrap max-md:max-w-full"
      >
        <div class="flex flex-col mt-2.5 text-neutral-700">
          <h2 class="text-xl font-bold">미참여 활동</h2>
          <p class="mt-3 text-base font-semibold">
            마감 기감에 맞춰 참여해주세요.
          </p>
        </div>
        <button
          class="flex gap-2.5 px-4 py-1.5 text-base whitespace-nowrap rounded-xl border border-solid border-zinc-400 text-zinc-800"
        >
          <span>마감순</span>
          <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/4d5f2033e1b55d3a0a14f9fc826ebe512948002e546b8e56ca0867df9c18084d?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="" class="shrink-0 w-6 aspect-square" /> -->
        </button>
      </div>
      <div
        class="flex gap-4 justify-between mt-6 text-base font-medium text-neutral-700 max-md:flex-wrap"
      >
        <button
          class="justify-center items-center px-5 my-auto text-3xl text-center text-white whitespace-nowrap bg-black rounded-full h-[55px] w-[55px] max-md:pr-5"
        >
          &gt;
        </button>
        <article
          class="flex flex-col pt-10 pb-0.5 pl-8 bg-white rounded-xl border-2 border-blue-500 border-solid"
        >
          <h3 class="self-center text-xl font-bold">마음알기 설문1</h3>
          <p class="mt-8 max-md:mr-2.5">기간 : 2023년 9월 1일 ~ 12월 1일</p>
          <div class="self-center mt-3.5 text-red-600">D-70</div>
          <button
            class="justify-center items-center px-16 py-3.5 mt-8 text-white whitespace-nowrap bg-blue-500 rounded-[30px] max-md:px-5 max-md:mr-2.5"
          >
            시작하기
          </button>
          <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/91593eda53aa687cc06f44161f3aab8820c71ea461548dbdc6fc478f7c58ea4c?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Button image" class="self-end mt-6 max-w-full aspect-[1.28] w-[116px]" /> -->
        </article>
        <article
          class="flex flex-col pt-10 pb-0.5 pl-8 bg-white rounded-xl border-2 border-blue-500 border-solid"
        >
          <h3 class="self-center text-xl font-bold">마음알기 설문2</h3>
          <p class="mt-8 max-md:mr-2.5">기간 : 2023년 9월 1일 ~ 12월 1일</p>
          <div class="self-center mt-3.5 text-red-600">D-70</div>
          <button
            class="justify-center px-14 py-3.5 mt-8 text-white bg-sky-700 rounded-[30px] max-md:px-5 max-md:mr-2.5"
          >
            이어서 진행하기
          </button>
          <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/91593eda53aa687cc06f44161f3aab8820c71ea461548dbdc6fc478f7c58ea4c?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Button image" class="self-end mt-6 max-w-full aspect-[1.28] w-[116px]" /> -->
        </article>
        <article
          class="flex flex-col pt-10 pb-0.5 pl-8 bg-white rounded-xl border-2 border-blue-500 border-solid"
        >
          <h3 class="self-center text-xl font-bold text-center">
            마음알기 설문3
          </h3>
          <p class="mt-8 max-md:mr-2.5">기간 : 2023년 9월 1일 ~ 12월 1일</p>
          <div class="self-center mt-3.5 text-red-600">D-70</div>
          <button
            class="justify-center items-center px-16 py-3.5 mt-8 text-white whitespace-nowrap bg-blue-500 rounded-[30px] max-md:px-5 max-md:mr-2.5"
          >
            시작하기
          </button>
          <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/eef2bda804526c25779f08c6b11b5f8574a05c307061db570fa12cec14fb4983?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="survey button icon" class="self-end mt-6 max-w-full aspect-[1.28] w-[116px]" /> -->
        </article>
        <article
          class="flex flex-col pt-10 pb-0.5 pl-8 bg-white rounded-xl border-2 border-blue-500 border-solid"
        >
          <h3 class="self-center text-xl font-bold text-center">
            마음알기 설문4
          </h3>
          <p class="mt-8 max-md:mr-2.5">기간 : 2023년 9월 1일 ~ 12월 1일</p>
          <div class="self-center mt-3.5 text-red-600">D-70</div>
          <button
            class="justify-center items-center px-16 py-3.5 mt-8 text-white whitespace-nowrap bg-blue-500 rounded-[30px] max-md:px-5 max-md:mr-2.5"
          >
            시작하기
          </button>
          <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/a0d8c989fd029db590896719af8af339dea916812d80db80666d36ab650e1ee6?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="survey button icon" class="self-end mt-6 max-w-full aspect-[1.28] w-[116px]" /> -->
        </article>
        <button
          class="justify-center items-center px-5 my-auto text-3xl text-center text-white whitespace-nowrap bg-black rounded-full h-[55px] w-[55px] max-md:pl-5"
        >
          &gt;
        </button>
      </div>
      <section
        aria-labelledby="participation-activities"
        class="mt-20 ml-6 max-md:mt-10 max-md:ml-2.5"
      >
        <h2
          id="participation-activities"
          class="self-start text-xl font-bold text-neutral-700"
        >
          참여 활동
        </h2>
        <p
          class="self-start mt-3 text-base font-semibold text-neutral-700 max-md:ml-2.5"
        >
          참여한 활동 목록입니다.
        </p>
        <div
          class="flex gap-5 justify-between mt-6 w-full max-md:flex-wrap max-md:max-w-full"
        >
          <button
            class="justify-center items-center px-5 my-auto text-3xl text-center text-white whitespace-nowrap bg-black rounded-full h-[55px] w-[55px] max-md:pr-5"
          >
            &gt;
          </button>
          <article
            class="flex flex-col pt-10 pb-1 pl-8 bg-white rounded-xl border-2 border-solid border-zinc-600"
          >
            <h3
              class="self-center text-xl font-bold text-center text-neutral-700"
            >
              마음알기 설문5
            </h3>
            <p
              class="mt-7 text-base font-medium text-neutral-700 max-md:mr-2.5"
            >
              기간 : 2023년 9월 1일 ~ 12월 1일
            </p>
            <button
              class="justify-center px-6 py-3.5 mt-14 text-base font-medium text-white bg-zinc-600 rounded-[30px] max-md:px-5 max-md:mt-10 max-md:mr-2.5"
            >
              활동 참여가 완료되었어요!
            </button>
            <div
              class="flex gap-5 items-start self-end mt-2 max-w-full w-[171px]"
            >
              <div class="flex flex-col">
                <div
                  class="shrink-0 h-4 rounded-full bg-zinc-600 w-[15px]"
                ></div>
                <div
                  class="shrink-0 mt-1.5 rounded-full bg-zinc-600 h-[9px]"
                ></div>
              </div>
              <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/40207b6f0b3c08a7b95e55aaa52cedbedb0a34e360a34911352ced882d51a8e6?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="survey completion image" class="shrink-0 mt-4 max-w-full aspect-[1.3] w-[116px]" /> -->
            </div>
          </article>
          <article
            class="flex flex-col pt-10 pb-1 pl-8 bg-white rounded-xl border-2 border-solid border-zinc-600"
          >
            <h3
              class="self-center text-xl font-bold text-center text-neutral-700"
            >
              마음알기 설문6
            </h3>
            <p
              class="mt-7 text-base font-medium text-neutral-700 max-md:mr-2.5"
            >
              기간 : 2023년 9월 1일 ~ 12월 1일
            </p>
            <button
              class="justify-center px-6 py-3.5 mt-14 text-base font-medium text-white bg-zinc-600 rounded-[30px] max-md:px-5 max-md:mt-10 max-md:mr-2.5"
            >
              활동 참여가 완료되었어요!
            </button>
            <div
              class="flex gap-5 items-start self-end mt-2 max-w-full w-[171px]"
            >
              <div class="flex flex-col">
                <div
                  class="shrink-0 h-4 rounded-full bg-zinc-600 w-[15px]"
                ></div>
                <div
                  class="shrink-0 mt-1.5 rounded-full bg-zinc-600 h-[9px]"
                ></div>
              </div>
              <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/40207b6f0b3c08a7b95e55aaa52cedbedb0a34e360a34911352ced882d51a8e6?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="survey completion image" class="shrink-0 mt-4 max-w-full aspect-[1.3] w-[116px]" /> -->
            </div>
          </article>
          <button
            class="justify-center items-center px-5 my-auto text-3xl text-center text-white whitespace-nowrap bg-black rounded-full h-[55px] w-[55px] max-md:pl-5"
          >
            &gt;
          </button>
        </div>
      </section>
    </section>
    <footer
      class="flex flex-col justify-center mt-10 w-full text-base text-white bg-zinc-500 max-md:mt-10 max-md:max-w-full"
    >
      <div
        class="flex flex-col px-20 py-9 w-full bg-sky-800 border-t border-solid border-zinc-100 max-md:px-5 max-md:max-w-full"
      >
        <p class="max-md:max-w-full">개인정보처리방침</p>
        <div class="flex gap-5 mt-2 max-md:flex-wrap max-md:max-w-full">
          <address class="flex-auto my-auto not-italic max-md:max-w-full">
            세종특별자치시 남세종로 446 스마트허브4차 504호 TEL : 044-715-7915
            FAX : 070-4324-7900 COPYRIGHT© DATAEUM 2024. ALL RIGHT RESERVED.
          </address>
          <!-- <img src="https://cdn.builder.io/api/v1/image/assets/TEMP/3b074e6d1d6f1442ba6ee20df7127cdae2e22e86c3f1cf2dae3e1ed7755e9bad?apiKey=ce28460f29bb4fafa8e3905252f0ef12&" alt="Company Logo" class="shrink-0 max-w-full aspect-[3.57] w-[164px]" /> -->
        </div>
      </div>
    </footer>
  </div>
</template>

<script>
import { defineComponent } from 'vue';

export default defineComponent({
  name: 'AppComponent',
});
</script>
